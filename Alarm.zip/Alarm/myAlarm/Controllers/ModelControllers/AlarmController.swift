//
//  AlarmController.swift
//  myAlarm
//
//  Created by Christopher Alegre on 9/23/19.
//  Copyright © 2019 trevorAdcock. All rights reserved.
//

import UIKit

class AlarmController {
    
    static let shared = AlarmController()
    
    var myAlarms: [Alarm] = []
    
    //CRUD
    func addAlarm(fireDate: Date, name: String, enable: Bool) {
        let newAlarm = Alarm(fireDate: fireDate, name: name)
        myAlarms.append(newAlarm)
        //save
    }
    
    func updateAlarm(alarm: Alarm, fireDate: Date, name: String, enable: Bool) {
        alarm.fireDate = fireDate
        alarm.name = name
        //save
    }
    
    func delete(alarm: Alarm) {
        guard let alarmDeleted = myAlarms.firstIndex(of: alarm) else {return}
            myAlarms.remove(at: alarmDeleted)
        //save
        }
    
    func toggleEnable(alarm: Alarm) {
        alarm.enabled = !alarm.enabled
    }

}
    

